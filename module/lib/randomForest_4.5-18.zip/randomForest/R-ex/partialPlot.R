### Name: partialPlot
### Title: Partial dependence plot
### Aliases: partialPlot partialPlot.default partialPlot.randomForest
### Keywords: classif regression tree

### ** Examples

data(airquality)
airquality <- na.omit(airquality)
set.seed(131)
ozone.rf <- randomForest(Ozone ~ ., airquality)
partialPlot(ozone.rf, airquality, Temp)

data(iris)
set.seed(543)
iris.rf <- randomForest(Species~., iris)
partialPlot(iris.rf, iris, Petal.Width, "versicolor")



